import { useTranslation } from "react-i18next";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Github, Linkedin, Mail } from "lucide-react";

export default function Contact() {
  const { t } = useTranslation();

  return (
    <section id="contact" className="py-24">
      <div className="container mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="max-w-2xl mx-auto text-center"
        >
          <h2 className="text-3xl font-bold mb-4">{t("contact.title")}</h2>
          <div className="w-20 h-1 bg-primary mx-auto rounded-full mb-8" />
          
          <p className="text-lg text-muted-foreground mb-12">
            {t("contact.desc")}
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Button size="lg" className="gap-2 min-w-[160px]" asChild>
              <a href="mailto:gamelo741@gmail.com">
                <Mail className="h-5 w-5" />
                {t("contact.email")}
              </a>
            </Button>
            
            <Button variant="outline" size="lg" className="gap-2 min-w-[160px]" asChild>
              <a href="https://www.linkedin.com/in/gamel-omar-790a56365" target="_blank" rel="noopener noreferrer">
                <Linkedin className="h-5 w-5" />
                LinkedIn
              </a>
            </Button>
            
            <Button variant="outline" size="lg" className="gap-2 min-w-[160px]" asChild>
              <a href="https://github.com/gamelo741-cyber" target="_blank" rel="noopener noreferrer">
                <Github className="h-5 w-5" />
                GitHub
              </a>
            </Button>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
