import { useTranslation } from "react-i18next";
import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { BookOpen, Award, Terminal, Code2 } from "lucide-react";

export default function About() {
  const { t } = useTranslation();

  const schools = [
    { 
      name: "Elzero Web School", 
      icon: Terminal, 
      url: "https://elzero.org/",
      logo: "https://avatars.githubusercontent.com/u/23116541?s=200&v=4"
    },
    { name: "Codezilla Web School", icon: Code2, url: "https://www.codezilla.courses/" },
    { name: "Mohamed Abu-Hadhoud Web School", icon: BookOpen, url: "https://programmingadvices.com/" },
  ];
  
  return (
    <section id="about" className="py-24 bg-secondary/30">
      <div className="container mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="max-w-4xl mx-auto"
        >
          <div className="flex flex-col md:flex-row gap-12 items-start">
            <div className="flex-1">
              <h2 className="text-3xl font-bold mb-6 flex items-center gap-3">
                <span className="w-12 h-1 bg-primary rounded-full"></span>
                {t("about.title")}
              </h2>
              <p className="text-lg text-muted-foreground leading-relaxed mb-8">
                {t("about.bio")}
              </p>
              
              <div className="space-y-6">
                <h3 className="text-xl font-semibold">{t("about.education_title")}</h3>
                <p className="text-muted-foreground">
                  {t("about.education_desc")}
                </p>
                
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-6">
                  {schools.map((school, i) => (
                    <a 
                      key={i} 
                      href={school.url} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="block group"
                    >
                      <Card className="bg-background border-none shadow-sm group-hover:shadow-md group-hover:bg-primary/5 transition-all h-full">
                        <CardContent className="p-4 flex flex-col items-center text-center gap-3">
                          <div className="p-3 bg-primary/10 rounded-full text-primary group-hover:scale-110 transition-transform flex items-center justify-center overflow-hidden w-12 h-12">
                            {school.logo ? (
                              <img src={school.logo} alt={school.name} className="w-full h-full object-cover" />
                            ) : (
                              <school.icon className="h-6 w-6" />
                            )}
                          </div>
                          <span className="font-medium text-sm">{school.name}</span>
                        </CardContent>
                      </Card>
                    </a>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
