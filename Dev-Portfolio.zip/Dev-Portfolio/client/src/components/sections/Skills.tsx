import { useTranslation } from "react-i18next";
import { motion } from "framer-motion";
import { Badge } from "@/components/ui/badge";
import { 
  Code, 
  Database, 
  Layout, 
  Smartphone, 
  GitBranch, 
  Brain, 
  Zap, 
  Search, 
  Users 
} from "lucide-react";

export default function Skills() {
  const { t } = useTranslation();

  const techSkills = [
    { key: "html_css", icon: Layout },
    { key: "js_ts", icon: Code },
    { key: "react", icon: Smartphone },
    { key: "backend", icon: Database },
    { key: "responsive", icon: Layout },
    { key: "git", icon: GitBranch },
  ];

  const softSkills = [
    { key: "problem_solving", icon: Brain },
    { key: "analytical", icon: Search },
    { key: "fast_learning", icon: Zap },
    { key: "self_motivation", icon: Zap }, // Reusing Zap or finding another
    { key: "clean_code", icon: Code },
  ];

  return (
    <section id="skills" className="py-24">
      <div className="container mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="max-w-4xl mx-auto"
        >
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold mb-4">{t("skills.title")}</h2>
            <div className="w-20 h-1 bg-primary mx-auto rounded-full" />
          </div>

          <div className="grid md:grid-cols-2 gap-12">
            {/* Tech Skills */}
            <div>
              <h3 className="text-xl font-semibold mb-6 flex items-center gap-2">
                <Code className="h-5 w-5 text-primary" />
                {t("skills.tech_title")}
              </h3>
              <div className="grid gap-4">
                {techSkills.map((skill, index) => (
                  <motion.div 
                    key={skill.key}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.1 }}
                    className="flex items-center gap-4 p-4 rounded-lg bg-secondary/50 border border-border/50"
                  >
                    <div className="p-2 bg-background rounded-md shadow-sm text-primary">
                      <skill.icon className="h-5 w-5" />
                    </div>
                    <span className="font-medium">{t(`skills.tech_list.${skill.key}`)}</span>
                  </motion.div>
                ))}
              </div>
            </div>

            {/* Soft Skills */}
            <div>
              <h3 className="text-xl font-semibold mb-6 flex items-center gap-2">
                <Brain className="h-5 w-5 text-primary" />
                {t("skills.soft_title")}
              </h3>
              <div className="flex flex-wrap gap-3">
                {softSkills.map((skill, index) => (
                  <motion.div
                    key={skill.key}
                    initial={{ opacity: 0, scale: 0.9 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <Badge variant="secondary" className="px-4 py-2 text-sm font-normal">
                      {t(`skills.soft_list.${skill.key}`)}
                    </Badge>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
