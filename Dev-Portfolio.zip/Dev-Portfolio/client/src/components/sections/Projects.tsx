import { useTranslation } from "react-i18next";
import { motion } from "framer-motion";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Github, ExternalLink, Globe } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Projects() {
  const { t } = useTranslation();

  return (
    <section id="projects" className="py-24 bg-secondary/30">
      <div className="container mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="max-w-5xl mx-auto"
        >
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold mb-4">{t("projects.title")}</h2>
            <div className="w-20 h-1 bg-primary mx-auto rounded-full" />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="overflow-hidden border-none shadow-lg flex flex-col h-full group">
              <div className="h-48 bg-gradient-to-br from-primary/20 to-blue-600/20 flex items-center justify-center group-hover:scale-105 transition-transform duration-500">
                <Globe className="h-16 w-16 text-primary/60" />
              </div>
              <CardHeader>
                <CardTitle>{t("projects.portfolio_title")}</CardTitle>
                <CardDescription className="flex gap-2 mt-2">
                  <Badge variant="outline">React</Badge>
                  <Badge variant="outline">Tailwind</Badge>
                  <Badge variant="outline">i18n</Badge>
                </CardDescription>
              </CardHeader>
              <CardContent className="flex-grow">
                <p className="text-muted-foreground text-sm leading-relaxed">
                  {t("projects.portfolio_desc")}
                </p>
              </CardContent>
              <CardFooter className="gap-3">
                <Button variant="outline" size="sm" className="w-full gap-2">
                  <Github className="h-4 w-4" /> Code
                </Button>
                <Button size="sm" className="w-full gap-2">
                  <ExternalLink className="h-4 w-4" /> Demo
                </Button>
              </CardFooter>
            </Card>

            {/* Placeholder for future projects */}
            {[1, 2].map((i) => (
              <Card key={i} className="overflow-hidden border-dashed border-2 bg-transparent shadow-none flex flex-col items-center justify-center h-full p-8 text-center text-muted-foreground/50">
                 <div className="p-4 rounded-full bg-muted mb-4">
                   <ExternalLink className="h-8 w-8" />
                 </div>
                 <p className="font-medium">Coming Soon</p>
              </Card>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
