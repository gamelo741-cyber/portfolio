import { useTranslation } from "react-i18next";
import { Button } from "@/components/ui/button";
import { ArrowRight, ArrowLeft, Code2 } from "lucide-react";
import { motion } from "framer-motion";
import heroBg from "@assets/generated_images/minimalist_abstract_geometric_shapes_background.png";

export default function Hero() {
  const { t, i18n } = useTranslation();
  const isRTL = i18n.language === "ar";

  const handleScroll = (id: string) => {
    const element = document.querySelector(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section id="hero" className="relative min-h-screen flex items-center pt-16 overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-background/90 dark:bg-background/95 backdrop-blur-[2px] z-10" />
        <img 
          src={heroBg} 
          alt="Background" 
          className="w-full h-full object-cover opacity-50 dark:opacity-20"
        />
      </div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-3xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-medium mb-6">
              <Code2 className="h-4 w-4" />
              <span>Full Stack Developer</span>
            </div>
            
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold tracking-tight mb-6 text-foreground">
              {t("hero.greeting")} <span className="text-primary">{t("hero.name")}</span>
            </h1>
            
            <h2 className="text-2xl md:text-3xl font-medium text-muted-foreground mb-8">
              {t("hero.subtitle")}
            </h2>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <Button 
                size="lg" 
                onClick={() => handleScroll("#projects")}
                className="gap-2 text-base h-12 px-8"
              >
                {t("hero.cta")}
                {isRTL ? <ArrowLeft className="h-4 w-4" /> : <ArrowRight className="h-4 w-4" />}
              </Button>
              
              <Button 
                variant="outline" 
                size="lg" 
                onClick={() => handleScroll("#contact")}
                className="gap-2 text-base h-12 px-8"
              >
                {t("nav.contact")}
              </Button>
            </div>
          </motion.div>
        </div>
      </div>
      
    </section>
  );
}
