import { useTranslation } from "react-i18next";
import { Github, Linkedin, Mail } from "lucide-react";

export default function Footer() {
  const { t } = useTranslation();
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-muted/30 border-t border-border py-12">
      <div className="container mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-6">
        <div className="text-sm text-muted-foreground text-center md:text-left">
          &copy; {currentYear} DevPortfolio. {t("projects.portfolio_desc").split(".")[0]}.
        </div>
        
        <div className="flex items-center gap-6">
          <a href="https://github.com/gamelo741-cyber" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-primary transition-colors">
            <Github className="h-5 w-5" />
          </a>
          <a href="https://www.linkedin.com/in/gamel-omar-790a56365" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-primary transition-colors">
            <Linkedin className="h-5 w-5" />
          </a>
          <a href="mailto:gamelo741@gmail.com" className="text-muted-foreground hover:text-primary transition-colors">
            <Mail className="h-5 w-5" />
          </a>
        </div>
      </div>
    </footer>
  );
}
