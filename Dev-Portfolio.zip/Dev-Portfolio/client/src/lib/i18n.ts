import i18n from "i18next";
import { initReactI18next } from "react-i18next";

const resources = {
  en: {
    translation: {
      nav: {
        home: "Home",
        about: "About",
        skills: "Skills",
        projects: "Projects",
        contact: "Contact"
      },
      hero: {
        greeting: "Hello, I'm",
        name: "Gamel Omar",
        title: "Junior Full-Stack Developer",
        subtitle: "Building modern, responsive, and user-friendly web applications.",
        cta: "View My Work"
      },
      about: {
        title: "About Me",
        bio: "I am a passionate Junior Full-Stack Developer with a strong foundation in modern web technologies. My journey into programming has been self-driven and rigorous, fueled by a curiosity to understand how the digital world is built.",
        education_title: "My Learning Journey",
        education_desc: "I have honed my skills through intensive online learning platforms including Elzero Web School, Codezilla Web School, and Mohamed Abu-Hadhoud Web School. These experiences have taught me not just how to code, but how to think like a programmer and solve complex problems.",
      },
      skills: {
        title: "Skills & Expertise",
        tech_title: "Technical Skills",
        soft_title: "Soft Skills",
        tech_list: {
          html_css: "HTML5 & CSS3",
          js_ts: "JavaScript & TypeScript",
          react: "React & Modern Frontend",
          backend: "Backend Logic (Flask)",
          responsive: "Responsive Design",
          git: "Git & Version Control"
        },
        soft_list: {
          problem_solving: "Problem Solving",
          analytical: "Analytical Thinking",
          fast_learning: "Fast Learning",
          self_motivation: "Self-Motivation",
          clean_code: "Clean & Readable Code"
        }
      },
      projects: {
        title: "Featured Projects",
        portfolio_title: "Personal Portfolio Website",
        portfolio_desc: "This website itself is a testament to my frontend development skills. Built with React and Tailwind CSS, it features a fully responsive design, dark/light theme switching, and bilingual support (English/Arabic). It demonstrates my ability to create clean, maintainable code and polished user interfaces."
      },
      contact: {
        title: "Get In Touch",
        desc: "I'm always open to discussing new projects, creative ideas or opportunities to be part of your visions.",
        email: "Email Me"
      }
    }
  },
  ar: {
    translation: {
      nav: {
        home: "الرئيسية",
        about: "عني",
        skills: "المهارات",
        projects: "المشاريع",
        contact: "تواصل معي"
      },
      hero: {
        greeting: "مرحباً، أنا",
        name: "جميل عمر",
        title: "مطور ويب شامل مبتدئ",
        subtitle: "أقوم ببناء تطبيقات ويب حديثة، متجاوبة، وسهلة الاستخدام.",
        cta: "شاهد أعمالي"
      },
      about: {
        title: "نبذة عني",
        bio: "أنا مطور ويب مبتدئ شغوف، أتميز بقدرة عالية على التعلم الذاتي وحل المشكلات التقنية المعقدة. أسعى دائماً لبناء واجهات مستخدم جذابة وتطبيقات ويب متكاملة تدمج بين الإبداع التصميمي وجودة الكود البرمجي. رحلتي بدأت بفضول عميق لاستكشاف العالم الرقمي، وتحولت اليوم إلى مسار مهني ملتزم بتقديم حلول برمجية مبتكرة.",
        education_title: "رحلتي التعليمية",
        education_desc: "لقد صقلت مهاراتي من خلال منصات التعلم المكثفة عبر الإنترنت بما في ذلك Elzero Web School و Codezilla Web School ومدرسة محمد أبو هدهود. علمتني هذه التجارب ليس فقط كيفية كتابة الكود، ولكن كيف أفكر كمبرمج وأحل المشكلات المعقدة."
      },
      skills: {
        title: "المهارات والخبرات",
        tech_title: "المهارات التقنية",
        soft_title: "المهارات الشخصية",
        tech_list: {
          html_css: "HTML5 & CSS3",
          js_ts: "JavaScript & TypeScript",
          react: "React & واجهات حديثة",
          backend: "منطق الخلفية (Flask)",
          responsive: "تصميم متجاوب",
          git: "Git & التحكم بالنسخ"
        },
        soft_list: {
          problem_solving: "حل المشكلات",
          analytical: "تفكير تحليلي",
          fast_learning: "تعلم سريع",
          self_motivation: "تحفيز ذاتي",
          clean_code: "كود نظيف ومقروء"
        }
      },
      projects: {
        title: "مشاريع مميزة",
        portfolio_title: "موقع معرض الأعمال الشخصي",
        portfolio_desc: "هذا الموقع بحد ذاته دليل على مهاراتي في تطوير الواجهات الأمامية. تم بناؤه باستخدام React و Tailwind CSS، ويتميز بتصميم متجاوب بالكامل، وتبديل بين الوضع الداكن/الفاتح، ودعم ثنائي اللغة (الإنجليزي/العربي). يوضح قدرتي على إنشاء كود نظيف وقابل للصيانة وواجهات مستخدم مصقولة."
      },
      contact: {
        title: "تواصل معي",
        desc: "أنا دائماً منفتح لمناقشة مشاريع جديدة، أفكار إبداعية أو فرص لأكون جزءاً من رؤاكم.",
        email: "راسلني"
      }
    }
  }
};

i18n
  .use(initReactI18next)
  .init({
    resources,
    lng: "en", // default language
    fallbackLng: "en",
    interpolation: {
      escapeValue: false
    }
  });

export default i18n;
